#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "v5.h"
#include "v5_vcs.h"
//
//Make sure the brain object is called "Brain"
vex::brain Brain;
//Make sure the controller object is called "Controller"
vex::controller Controller;
/*Declare all other objects below*/